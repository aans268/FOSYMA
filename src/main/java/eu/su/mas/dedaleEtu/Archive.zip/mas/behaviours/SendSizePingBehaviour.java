package eu.su.mas.dedaleEtu.mas.behaviours;

import jade.core.behaviours.SimpleBehaviour;

public class SendSizePingBehaviour extends SimpleBehaviour {

	@Override
	/**
	 * Envoi 
	 */
	public void action() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean done() {
		// TODO Auto-generated method stub
		return false;
	}

}
